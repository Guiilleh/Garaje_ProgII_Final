package herencia0;

public class Vehiculo {
    
    public int potencia;
    
    public Vehiculo(int potencia) {
	this.potencia = potencia;
    }
    
    public String Mostrar() {
	return "La potencia es: " + potencia;
    }
}
