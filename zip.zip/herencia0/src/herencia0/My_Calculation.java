/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia0;

/**
 *
 * @author Admin
 */
public class My_Calculation extends Calculation {		    // MAIN CLASS

    public void multiplication(int x, int y) {			    // METHOD OF MAIN CLASS
	z = x * y;
	System.out.println("The product of the given numbers: " + z);
    }

    public static void main(String args[]) {
	int a = 20, b = 10;
	My_Calculation demo = new My_Calculation();		    // OBJECT OF MAIN CLASS, HAS ACCESS TO ALL FUNCTIONS
	demo.multiplication(a, b);				    // FUNCTION OF MAIN CLASS
	demo.addition(a, b);					    // FUNCTION OF EXTENDED CLASS
	demo.Subtraction1(a, b);				    // FUNCTION OF EXTENDED CLASS
	System.out.println("The difference between the given numbers: " + demo.Subtraction2(a, b));
    }
}

class Calculation {






    int z;

    public void addition(int x, int y) {
	z = x + y;
	System.out.println("The sum of the given numbers: " + z);
    }
    
    public void Subtraction1(int x, int y) {
	z = x - y;
	System.out.println("The difference between the given numbers: " + z);
    }

    public int Subtraction2(int x, int y) {
	z = x - y;
	//System.out.println("The difference between the given numbers: " + z);
	return z;
    }
}
