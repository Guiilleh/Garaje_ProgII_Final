package herencia0;
/*
    super: función para acceder a valores públicos de la clase padre
    extends: palabra reservada para darle acceso a los valores públicos de una clase a otra
    this:
    Clase padre: clase que proporciona objetos
    clase hija: clase que recibe los objetos de la clase padre
    redefinición de método: acción que consiste en reescribir un método, ya sea con diferentes parámetro o con diferente tipo
*/

public class Garaje {

    public static void main(String[] args) {
	Garaje g = new Garaje();
	Coche c1 = new Coche(101,5);
	Moto m1 = new Moto(3);
	
	System.out.println(c1.Mostrar());
	System.out.println(m1.Mostrar());
	
	g.Cuota(m1.getPotencia()); // moto
	g.Cuota(c1.getPotencia(), c1.getNumPlazas()); // coche
	g.Cuota(); // vacía
    }
    
    int numPlazas;
    
    public Garaje() {
	this.numPlazas = 4; // especificar numero de plazas en constructor??
    }
    
    public void Cuota(int potencia) {
	int cuota = potencia * 2;
	System.out.println("La cuota mensual de la plaza Moto es: " + cuota);
    }
    
    public void Cuota(int potencia, int numPlazas) {
	int cuota = potencia * numPlazas;
	System.out.println("La cuota mensual de la plaza Coche es: " + cuota);
    }
    
    public void Cuota() {
	System.out.println("La cuota para dicha plaza es: 0");
    }
}
