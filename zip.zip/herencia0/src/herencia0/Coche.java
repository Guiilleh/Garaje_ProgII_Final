package herencia0;

public class Coche extends Vehiculo {
    
    public int numPlazas;
    
    public Coche(int potencia, int numPlazas) {
	super(potencia);
	this.numPlazas = numPlazas;
    }
    
    public int getPotencia() {
	return potencia;
    }
    
    public int getNumPlazas() {
	return numPlazas;
    }
    
    @Override
    public String Mostrar() {
	return "Coche\n" + super.Mostrar() + "\nEl número de plazas es: " + numPlazas + "\n";
    }
}
