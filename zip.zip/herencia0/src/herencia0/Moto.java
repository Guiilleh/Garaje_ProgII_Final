package herencia0;

public class Moto extends Vehiculo {
    
    public Moto(int potencia) {
	super(potencia);
    }
    
    public int getPotencia() {
	return potencia;
    }
    
    @Override
    public String Mostrar() {
	return "Moto\n" + super.Mostrar() + "\n";
    }
}
